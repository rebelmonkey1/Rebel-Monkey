# Rebel Monkey - Fashion Designers Marketplace

Rebel Monkey is a web platform connecting Nigerian fashion designers and customers.

## Features
- Customers upload body measurements & cloth style requests
- Designers sign up with verification documents
- Admin approves designer registrations and job requests
- Notifications for designers on job approvals/rejections
- Client and Designer dashboards
- African-themed UI with bright colors, gold & white

## Setup
1. Clone the repo
2. Install dependencies (`npm install`)
3. Configure `.env` with DATABASE_URL and NEXTAUTH_SECRET
4. Run Prisma migrations (`npx prisma migrate dev`)
5. Run dev server (`npm run dev`)

## Deployment
Deploy on Vercel, setting environment variables on the dashboard.